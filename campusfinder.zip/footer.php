</div>
</article></div>
                    </div>
                </div>
            </div><footer class="art-footer clearfix">
<a href="http://www.kopertis4.or.id/" class="active">Kopertis Wilayah IV</a>
<p>Copyright © 2013. Informasi Kampus Kota Bandung.</p>
</footer>

    </div>
    
</div>


</body></html>