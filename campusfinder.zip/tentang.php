<?php
include 'header.php';
?>
<marquee>Test Tentang </marquee>
<?php
include 'footer.php';
?>