<?php
class Prodi{
	private $kode_pt;
	private $kode_prodi;
	private $nama_prodi;
	
	function __construct(){
		include 'koneksi.php';
	}
	
	public function set_kode_pt($kode_pt){
		$this->kode_pt=$kode_pt;
	}
	
	public function get_kode_pt(){
		return $this->kode_pt;
	}
	
	public function set_kode_prodi($kode_prodi){
		$this->kode_prodi=$kode_prodi;
	}
	
	public function get_kode_prodi(){
		return $this->kode_prodi;
	}
	
	public function set_nama_prodi($nama_prodi){
		$this->nama_prodi=$nama_prodi;
	}
	
	public function get_nama_prodi(){
		return $this->nama_prodi;
	}
	
	public function save(){
		$result=mysql_query("INSERT INTO prodi_kampus VALUES('{$this->kode_pt}', '{$this->kode_prodi}')");
		if($result){
			return true;
		}else{
			return false;
		}
	}
	
	public function update($kode_prodi){
		$result=mysql_query("UPDATE prodi_kampus SET kode_prodi='{$this->kode_prodi}' WHERE kode_pt='{$this->kode_pt}' AND kode_prodi='$kode_prodi'");
		if($result){
			return true;
		}else{
			return false;
		}
	}
	
	public function delete(){
		$result=mysql_query("DELETE FROM prodi_kampus WHERE kode_pt='{$this->kode_pt}' AND kode_prodi='{$this->kode_prodi}'");
		if($result){
			return true;
		}else{
			return false;
		}
	}
	
	public function select($kode_pt){
		$daftar_prodi=array();
		$i=0;
		$result=mysql_query("SELECT kode_pt, prodi_kampus.kode_prodi, prodi.nama_prodi FROM prodi_kampus inner join prodi on prodi.kode_prodi=prodi_kampus.kode_prodi WHERE kode_pt='$kode_pt'");
		while($row=mysql_fetch_array($result)){
			$p=new Prodi();
			$p->set_kode_pt($row['kode_pt']);
			$p->set_kode_prodi($row['kode_prodi']);
			$p->set_nama_prodi($row['nama_prodi']);
			$daftar_prodi[$i]=$p;
			$i++;
		}
		
		return $daftar_prodi;
	}
}

?>