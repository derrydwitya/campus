<?php
include 'header.php';
?>
<marquee>Test tutorial </marquee>
<?php
include 'footer.php';
?>