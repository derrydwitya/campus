<?php
mysql_connect("localhost","infk6416_root","infk6416_root");
mysql_select_db("infk6416_campusfinder");
?>