<?php
session_start();
include 'koneksi.php';

$username=$_POST['username'];
$password=$_POST['password'];

$result=mysql_query("select * from pengguna where username='$username' and password='$password'");
$jumlah=mysql_num_rows($result);
if($jumlah==1){
	$_SESSION['username']=$username;
	header('Location:home.php');
}else{
	header('Location:login_view.php?error=1');
}
?>